package org.cap.boot;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Address;
import org.cap.model.Department;
import org.cap.model.Employee;

public class MainClass {

	
	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager= factory.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		
		
		/*String query="from Employee e where e.salary > :param_salary";
		Query query2= entityManager.createQuery(query);
		query2.setParameter("param_salary", 5000.0);
		
		List<Employee> employees= query2.getResultList();
		for(Employee emp: employees)
			System.out.println(emp);*/
		
		// Selective Column Fetch
		Query qry = entityManager.createQuery("select e.employeeId, e.firstName, e.lastName from Employee e");
		List resultList = qry.getResultList();
		Iterator iterator = resultList.iterator();
		while(iterator.hasNext()){
			Object obj[] = (Object[]) iterator.next();
			System.out.println("Employee Id: " +obj[0]+ " , Name: " +obj[1].toString().concat(obj[2].toString()));
		}
		
		//Patterns search - Starts with and contains
		Query query = entityManager.createQuery("SELECT emp FROM Employee emp WHERE emp.firstName LIKE 'J%' and emp.salary LIKE '%_543_%'");
		List<Employee> employees = query.getResultList();
		for(Employee e: employees){
			System.out.println("EmpId>>> " +e);
		}
		
		// Aggregate Funtion implementation
		// Count
		Query query1 = entityManager.createQuery("SELECT COUNT(e) FROM Employee e");
		Long empCount = (Long) query1.getSingleResult();
		System.out.println("Total Employees count is >>>" +empCount);
		
		// Min
		Query query2 = entityManager.createQuery("SELECT min(e.salary) FROM Employee e");
		Double minSalary = (Double) query2.getSingleResult();
		System.out.println(" Min Salary of Employee is " +minSalary);
		
		// Max
		Query query3 = entityManager.createQuery("SELECT max(e.salary) FROM Employee e");
		Double maxSalary = (Double) query3.getSingleResult();
		System.out.println(" Max Salary of Employee is " +maxSalary);
		
		// Avg and Count
		//Query query4 = entityManager.createQuery("SELECT COUNT(e) FROM employee e where e.salary > (select avg(salary) from employee)");
		Query query4 = entityManager.createQuery("select count(e) FROM Employee e GROUP BY e.salary HAVING e.salary > (select avg(salary) from Employee)");
		Long empAvgSalCount = (Long) query4.getSingleResult();
		System.out.println("Total Employees count whose salary > Average salary is: " +empAvgSalCount);
		
		//select query by Id
		
		  /*Employee employee=entityManager.find(Employee.class, 1000);
		  System.out.println(employee); employee.setSalary(34000);*/
		 
		
		//delete query
		//entityManager.remove(employee);
		
		/* Address address=new Address(); address.setStreetName("South Avvenue");
		 address.setCity("Mumbai");
		 
		 Address address1=new Address(); address1.setStreetName("North Avvenue");
		 address1.setCity("Chennai");
		 
		 Department department=new Department("Sales","NorthEast"); Department
		 department1=new Department("Marketing","NorthEast"); Department
		  department2=new Department("Finance","NorthEast");
		  
		  Employee employee=new Employee("tom", "Jack", 120000); Employee employee1=new
		  Employee("Jerry", "thomson", 45435); Employee employee2=new Employee("Ram",
		  "Singh", 4566767); Employee employee3=new Employee("Annie", "George", 120000);
		  
		  // employee.getAddresses().add(address);
		  employee.getAddresses().add(address1); employee.setDepartment(department);
		  employee1.setDepartment(department); employee2.setDepartment(department1);
		  employee3.setDepartment(department2);
		  
		  
		  address.setEmployee(employee); address1.setEmployee(employee);
		  
		  
		  entityManager.persist(employee); entityManager.persist(employee1);
		  entityManager.persist(employee2); entityManager.persist(employee3);
		  entityManager.persist(department); entityManager.persist(department1);
		  entityManager.persist(department2); entityManager.persist(address);
		  entityManager.persist(address1);*/
		 
		transaction.commit();
		entityManager.close();
		factory.close();
		
		
		
	}

}
