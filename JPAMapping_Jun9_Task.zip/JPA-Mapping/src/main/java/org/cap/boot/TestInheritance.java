package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.inherit.Module;
import org.cap.inherit.Project;
import org.cap.inherit.Task;

public class TestInheritance {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager= factory.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		
			Project project=new Project(1001, "CITI Bank");
			Project project1=new Project(435435, "SCB Bank");
			
			Module module=new Module();
			module.setProjectId(1111);
			module.setProjectName("AXBI Banking");
			module.setModuleName("Login Module");
		
			Task task=new Task();
			task.setProjectId(1900);
			task.setProjectName("North American Banking");
			task.setModuleName("Report Module");
			task.setTaskName("Execute Batch");
			
			
			entityManager.persist(project);
			entityManager.persist(project1);
			entityManager.persist(module);
			entityManager.persist(task);
		
		transaction.commit();
		entityManager.close();
		factory.close();
	}

}
