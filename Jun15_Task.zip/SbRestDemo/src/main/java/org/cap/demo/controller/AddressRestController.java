package org.cap.demo.controller;

import org.cap.demo.service.IAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;

@RestController
@RequestMapping("/app/v2")
public class AddressRestController {

	@Autowired
    private IAddressService addressService;
	
	 @GetMapping("/get-address")
	    public ResponseEntity<List<Address>> getAllAddress() {
	 
	        List<Address> addresses = addressService.getAllAddress();
	        return new ResponseEntity<>(addresses, HttpStatus.OK);
	    }
	 
	    @PostMapping("/address")
	    public ResponseEntity<Address> saveEmployee(@RequestBody Address address) {
	 
	        Address address2 = addressService.addAddress(address);
	        return new ResponseEntity<>(address2, HttpStatus.OK);
	    }
	 
	    @PutMapping("/address")
	    public ResponseEntity<Address> updateAddress(@RequestBody Address entity) {
	 
	        Address address = addressService.editAddress(entity);
	        return new ResponseEntity<>(address, HttpStatus.OK);
	    }
	 
	    @DeleteMapping("/address/{id}")
	    public ResponseEntity<String> deleteEmployee(@PathVariable(value = "id") Integer addressId) {
	 
	    	addressService.deleteEmployees(addressId);
	        return new ResponseEntity<>("Address with ID :" + addressId + " deleted successfully", HttpStatus.OK);
	    }
}
