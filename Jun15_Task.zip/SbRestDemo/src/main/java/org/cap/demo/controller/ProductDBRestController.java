package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.dao.IProductDBDao;
import org.cap.demo.dao.IProductDao;
import org.cap.demo.model.Product;
import org.cap.demo.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app/v2")
public class ProductDBRestController {
	@Autowired
	private IProductService productService;
	
	@GetMapping("/filtername/{pname}")
	public ResponseEntity<List<Product>> filterByprice(@PathVariable("pname")
				String pname){
		List<Product> products= productService.findByProductName(pname);
	
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	@GetMapping("/filterprice/{price}")
	public ResponseEntity<List<Product>> filterByprice(@PathVariable("price")
				double price){
		List<Product> products= productService.filterByPriceDetails(price);
	
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(
			@RequestBody Product product){
		List<Product> products= productService.saveProduct(product);
		
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! INsertion Failed!",
					HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);

	}
	
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProduct(
			@PathVariable("productId")Integer productId){
		Product product= productService.findProduct(productId);
	
		if(product==null) {
			return new ResponseEntity("Sorry! Product ID not exits!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	

	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products= productService.getAllProducts();
	
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@GetMapping("/nameSearchByPattern/{pname}")
	public ResponseEntity<List<Product>> wildCardSearch(@PathVariable("pname")
				String pname){
		List<Product> products= productService.namePatternSearch(pname);
	
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
}
