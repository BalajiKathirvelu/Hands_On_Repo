package org.cap.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.dao.IAddressDao;
import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("addressService")
public class AddressServiceImpl implements IAddressService{
	@Autowired 
	IAddressDao addressDBDao;
	
	@Autowired 
	IEmployeeDao employeeDBDao;

	@Override
	//@Transactional
	public List<Address> getAllAddress() {
		// TODO Auto-generated method stub
		return addressDBDao.findAll();
	}
	
	@Override
	@Transactional
	public Address addAddress(Address address) {
		 
        Employee emp = employeeDBDao.findById(address.getEmployee().getEmployeeId()).orElse(null);
        if (null == emp) {
            emp = new Employee();
        }
        emp.setFirstName(address.getEmployee().getFirstName());
        emp.setLastName(address.getEmployee().getLastName());
        emp.setSalary(address.getEmployee().getSalary());
        address.setEmployee(emp);
        return addressDBDao.save(address);
    }
	
	@Override
	public Address editAddress(Address entity) {
		 
        return addressDBDao.save(entity);
    }
	
	@Override
    public void deleteEmployees(Integer id) {
 
    	addressDBDao.deleteById(id);
    }
	
}
