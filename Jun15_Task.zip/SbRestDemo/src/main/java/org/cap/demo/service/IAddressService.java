package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Address;

public interface IAddressService {

	public List<Address> getAllAddress();

	Address addAddress(Address address);

	Address editAddress(Address entity);

	void deleteEmployees(Integer id);

}
