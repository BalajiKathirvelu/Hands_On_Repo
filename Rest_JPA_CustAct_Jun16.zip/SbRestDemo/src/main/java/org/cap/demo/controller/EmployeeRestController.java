package org.cap.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/app/v2")

public class EmployeeRestController {

	@Autowired
	private IEmployeeService employeeService;
	
	@PostMapping("/employees")
	@ApiOperation(nickname = "CreateEmployees",value = "Create or Save Employee Details.")
	
	public ResponseEntity<List<Employee>> createOrSaveEmployee(
			@RequestBody Employee employee){
		List<Employee> employees= employeeService.saveEmployee(employee);
		
		if(employees==null|| employees.isEmpty()) {
			return new ResponseEntity("Sorry! Insertion Failed!",
					HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);

	}
	
	@GetMapping("/employees")
	@ApiOperation(nickname = "AllEmployees",value = "Get All Employees from DB.")
	
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> employees= employeeService.getAllEmployees();
	//System.out.println("Address check " +employees.get(0).getAddresses());
		if(employees==null|| employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@PutMapping("/employees")
	@ApiOperation(nickname = "Update Employees",value = "Update Employee Details Partially.")
    public ResponseEntity<Employee> updateEmps(@RequestBody Employee entity) {
 
        Employee employee = employeeService.editEmployee(entity);
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }
	
	@PatchMapping("/employees/{id}")
	@ApiOperation(nickname = "Update Employees Partially",value = "Update Employee Details Partially.")
	@ApiImplicitParams({
		@ApiImplicitParam(value = "employeeId",dataType = "Integer")
	})
	public ResponseEntity<List<Employee>> updateEmployee(@PathVariable(value = "id") Integer employeeId,
			 @RequestBody Employee employeeDetails){
		Employee employee = employeeService.findEmployee(employeeId);
		System.out.println("Employee Obj >>>> " +employee);
		System.out.println("Employee Details >>>> " +employeeDetails);
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setSalary(employeeDetails.getSalary());
		List<Employee> updatedList =  employeeService.saveEmployee(employee);
		return ResponseEntity.ok(updatedList);
	}

	@DeleteMapping("/employees/{id}")
	@ApiOperation(nickname = "Delete Employees",value = "Delete Employee Details.")
	@ApiImplicitParams({
		@ApiImplicitParam(value = "employeeId",dataType = "Integer")
	})
	public ResponseEntity<String> deleteEmployee(@PathVariable(value = "id") Integer employeeId){
		employeeService.deleteEmployee(employeeId);
		return new ResponseEntity<>("Employee with ID :" + employeeId + " deleted successfully", HttpStatus.OK);
	}
	
	@GetMapping("/patternSearch/{searchString}")
		
	public ResponseEntity<List<Employee>> getNamePatternSearch(@PathVariable(value = "searchString") String searchString){
		List<Employee> employees = employeeService.namePatternSearch(searchString);
	if(employees==null|| employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@GetMapping("/sortByName")
	
	public ResponseEntity<List<Employee>> getSortedName(){
		List<Employee> sortedEmps = new ArrayList<>();
		List<Employee>  employees= employeeService.getAllEmployees();
		for(Employee emp: employees){
			sortedEmps = employeeService.findByOrderByFirstName(emp.getFirstName());
		}
	if(sortedEmps==null|| sortedEmps.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(sortedEmps, HttpStatus.OK);
	}
	
	/*@GetMapping("/fetchMinSalary")
	public ResponseEntity <List<Employee>> fetchMinSalary(){
		List<Employee> emps = employeeService.fetchEmployeeByMinSalary();
		if(emps==null || emps.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(emps, HttpStatus.OK);
	}
	
	@GetMapping("/fetchMaxSalary")
	public ResponseEntity <List<Employee>> fetchMaxSalary(){
		List<Employee> emps = employeeService.fetchEmployeeByMaxSalary();
		if(emps==null || emps.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(emps, HttpStatus.OK);
	}*/
	
	@GetMapping("/fetchMinSalary")
	public ResponseEntity<Double> fetchMinSalary(){
		Double minSalary = employeeService.fetchMinSalary();
				
		return new ResponseEntity<Double>(minSalary, HttpStatus.OK);
	}
	
	@GetMapping("/fetchMaxSalary")
	public ResponseEntity<Double> fetchMaxSalary(){
		Double minSalary = employeeService.fetchMaxSalary();
				
		return new ResponseEntity<Double>(minSalary, HttpStatus.OK);
	}
}
