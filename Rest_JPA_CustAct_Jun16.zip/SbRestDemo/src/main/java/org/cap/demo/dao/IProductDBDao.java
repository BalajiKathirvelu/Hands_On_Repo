package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("productDBDao")
public interface IProductDBDao extends JpaRepository<Product, Integer>{

	//JPQL Query
	@Query("from Product p where p.price > :param_price")
	public List<Product> filterByPriceDetails(
			@Param("param_price")double param_price);
	
	
	public List<Product> findByProductName(String productName);

	@Query("SELECT p FROM Product p WHERE p.productName LIKE %:pName%")
	public List<Product> wildCardSearch(@Param("pName") String pName);
	
	
	/*
	 * findByProductId(Integer productId) findByProductPriceBetween(Integer
	 * minvalue,integer maxvalue) findByProductNameAndPrice(String
	 * productName,double price) findByProductNameOrPrice(String productName,double
	 * price)
	 */
	
}
