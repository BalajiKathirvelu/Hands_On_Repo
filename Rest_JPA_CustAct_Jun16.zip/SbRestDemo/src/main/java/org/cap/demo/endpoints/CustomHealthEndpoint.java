package org.cap.demo.endpoints;

import java.util.LinkedHashMap;
import java.util.Map;

import org.cap.demo.model.CustomHealth;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="custom-health")

public class CustomHealthEndpoint {
	@ReadOperation
	 public CustomHealth health() {
	        Map<String, Object> details = new LinkedHashMap();
	        details.put("HealthStatus", "Status is Up");
	        CustomHealth health = new CustomHealth();
	        health.setHealthInfoMap(details);
	        return health;
	    }
}
