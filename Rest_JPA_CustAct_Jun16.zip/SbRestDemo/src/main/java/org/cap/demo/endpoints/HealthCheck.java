package org.cap.demo.endpoints;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;

public class HealthCheck implements HealthIndicator{

	@Override
	public Health health() {
		
		return null;
	}

}
