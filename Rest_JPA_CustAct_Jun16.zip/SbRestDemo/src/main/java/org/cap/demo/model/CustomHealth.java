package org.cap.demo.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;

public class CustomHealth {
	private Map<String, Object> healthInfoMap;

    public void setHealthInfoMap(Map<String, Object> healthInfoMap) {
		this.healthInfoMap = healthInfoMap;
	}

	@JsonAnyGetter
    public Map<String, Object> getHealthInfoMap() {
        return this.healthInfoMap;
    }
}
