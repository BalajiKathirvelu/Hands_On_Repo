package org.cap.conotroller;

import java.util.List;

import org.cap.dao.IEmployeeDao;
import org.cap.dao.IProductDao;
import org.cap.model.Employee;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/emp")
public class EmployeeDbController {
	@Autowired
	private IEmployeeDao employeeDbDao;
	
	@ApiIgnore
	@GetMapping("/allEmps")
	@ApiOperation(nickname = "AllEmployees",value = "Get All Employees from DB.")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> emps=employeeDbDao.getAllEmployees();
		
		if(emps==null || emps.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(emps, HttpStatus.OK);
	}
	
	 @PostMapping("/createOrSaveEmp")
	  public ResponseEntity<Employee> createEmp(@RequestBody Employee employee) {
		 System.out.println("create emp called");
	    try {
	      employeeDbDao.createorSaveEmployee(employee);
	      return new ResponseEntity<>(employee, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	 
	 @GetMapping(value="/emps/{employeeId}")
		@ApiOperation(nickname = "AllEmployees",value = "Get All Employees from DB.")
		@ApiImplicitParams({
			@ApiImplicitParam(value = "employeeId",dataType = "Integer")
		})
		public ResponseEntity<Employee> findEmployee (@PathVariable("employeeId") Integer employeeId ){
			Employee emp=employeeDbDao.findEmployee(employeeId);
			
			if(emp==null ) {
				return new ResponseEntity("Sorry!Product Id Not Found!", 
						HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		}
	 
	 @DeleteMapping("/deleteEmployee/{employeeId}")
		public ResponseEntity<List<Employee>> deleteEmployee(
				@PathVariable("employeeId") Integer employeeId){
			List<Employee> employees = employeeDbDao.deleteEmployee(employeeId);
			
			if(employees==null) {
				return new ResponseEntity("Sorry! Employee Id not exists! Deletion Error!", 
						HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
		}
	 
	 @PutMapping("/updateEmp/{employeeId}")
	 public ResponseEntity < ? > updateResource(@RequestBody Employee employeeDetails,
	  @PathVariable("employeeId") Integer employeeId) {
	  Employee employee = employeeDbDao.updateEmp(employeeDetails, employeeId);
	  return new ResponseEntity < > (employee, HttpStatus.OK);
	 }
	}
		
