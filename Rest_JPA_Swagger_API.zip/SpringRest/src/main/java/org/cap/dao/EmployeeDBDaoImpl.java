package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Employee;
import org.cap.model.Product;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("employeeDbDao")
@Transactional
public class EmployeeDBDaoImpl implements IEmployeeDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Employee findEmployee(Integer employeeId) {
		// TODO Auto-generated method stub
		Employee employee=entityManager.find(Employee.class, employeeId);
		return employee;
	}

	@Override
	public List<Employee> deleteEmployee(Integer employeeId) {
		Employee employee=entityManager.find(Employee.class, employeeId);
		entityManager.remove(employee);
		return getAllEmployees() ;
	}

	@Override
	public void createorSaveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("Inside createorSave method >>> " +employee.getEmployeeId()+ "," +employee.getFirstName());
		//entityManager.getTransaction().begin();
		entityManager.persist(employee);
		//entityManager.getTransaction().commit();
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> emps= entityManager.createQuery("from Employee").getResultList();
		return emps;
	}

	@Override
	public Employee updateEmp(Employee employeeDetails, Integer employeeId) {
		// TODO Auto-generated method stub
		Employee employee=entityManager.find(Employee.class, employeeId);
		employee.setFirstName("John");
		return employee;
	}
	
}
