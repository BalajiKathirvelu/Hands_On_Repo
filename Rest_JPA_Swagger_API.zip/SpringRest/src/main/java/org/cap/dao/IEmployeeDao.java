package org.cap.dao;

import java.util.List;

import org.cap.model.Employee;
import org.cap.model.Product;

public interface IEmployeeDao {
	public Employee findEmployee(Integer employeeId);

	public List<Employee> deleteEmployee(Integer employeeId);
	
	public void createorSaveEmployee(Employee employee);

	public List<Employee> getAllEmployees();

	public Employee updateEmp(Employee employeeDetails, Integer employeeId);
}
