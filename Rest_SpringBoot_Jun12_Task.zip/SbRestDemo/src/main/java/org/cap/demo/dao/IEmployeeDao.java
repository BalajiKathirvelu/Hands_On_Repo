package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("employeeDBDao")
public interface IEmployeeDao extends JpaRepository<Employee, Integer>{
	
	@Query("SELECT e FROM Employee e WHERE e.firstName || e.lastName LIKE %:name%")
	public List<Employee> wildCardSearch(@Param("name") String name);

	@Query(value = "SELECT * from Employee group by salary having min(salary)", nativeQuery = true)
	public List<Employee> fetchEmployeeByMinSalary();
	
	@Query(value = "SELECT * from Employee group by salary having max(salary)", nativeQuery = true)
	public List<Employee> fetchEmployeeByMaxSalary();
	
	@Query(value = "SELECT max(salary) from Employee", nativeQuery = true)
	public Double fetchMaxSalary();
	
	@Query(value = "SELECT min(salary) from Employee", nativeQuery = true)
	public Double fetchMinSalary();

}
