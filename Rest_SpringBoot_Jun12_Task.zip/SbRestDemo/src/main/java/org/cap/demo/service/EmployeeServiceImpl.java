package org.cap.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Employee;
import org.cap.demo.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired 
	IEmployeeDao employeeDBDao;
	
	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDBDao.findAll();
	}

	@Override
	public Employee findEmployee(Integer employeeId) {
		// TODO Auto-generated method stub
		return employeeDBDao.getOne(employeeId);
	}

	@Override
	public List<Employee> saveEmployee(Employee employee) {
		employeeDBDao.save(employee);
		return getAllEmployees();
	}

	@Override
	public List<Employee> filterBySalaryDetails(double salary) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findByEmployeeName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> namePatternSearch(String firstName) {
		// TODO Auto-generated method stub
		return employeeDBDao.wildCardSearch(firstName);
	}

	@Override
	public Map<String, Boolean> deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeDBDao.delete(employee);
		Map<String, Boolean> response = new HashMap();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
	
	@Override
	public List<Employee> findByOrderByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return employeeDBDao.findAll(Sort.by(Sort.Direction.ASC, "firstName"));
	}

	@Override
	public List<Employee> fetchEmployeeByMinSalary() {
		// TODO Auto-generated method stub
		return employeeDBDao.fetchEmployeeByMinSalary();
	}
	
	@Override
	public List<Employee> fetchEmployeeByMaxSalary() {
		// TODO Auto-generated method stub
		return employeeDBDao.fetchEmployeeByMaxSalary();
	}

	@Override
	public Double fetchMaxSalary() {
		// TODO Auto-generated method stub
		return employeeDBDao.fetchMaxSalary();
	}

	@Override
	public Double fetchMinSalary() {
		// TODO Auto-generated method stub
		return employeeDBDao.fetchMinSalary();
	}

}
