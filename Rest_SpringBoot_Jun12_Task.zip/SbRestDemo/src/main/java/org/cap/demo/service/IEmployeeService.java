package org.cap.demo.service;

import java.util.List;
import java.util.Map;

import org.cap.demo.model.Employee;
import org.cap.demo.model.Product;

public interface IEmployeeService {

	public List<Employee> getAllEmployees();

	public Employee findEmployee(Integer employeeId);

	public List<Employee> saveEmployee(Employee employee);
	
	public List<Employee> filterBySalaryDetails(double salary);
	
	public List<Employee> findByEmployeeName(String firstName);

	public List<Employee> namePatternSearch(String firstName);
	
	public Map<String, Boolean> deleteEmployee(Employee employee);

	public List<Employee> findByOrderByFirstName(String firstName);
	
	public List<Employee> fetchEmployeeByMinSalary();
	
	public List<Employee> fetchEmployeeByMaxSalary();

	public Double fetchMaxSalary();

	public Double fetchMinSalary();
}

