package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Product;
import org.springframework.data.repository.query.Param;

public interface IProductService {
	public List<Product> getAllProducts();

	public Product findProduct(Integer productId);

	public List<Product> saveProduct(Product product);
	
	public List<Product> filterByPriceDetails(double param_price);
	public List<Product> findByProductName(String productName);

	public List<Product> namePatternSearch(String pname);
}
