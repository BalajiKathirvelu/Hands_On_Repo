package org.cap.conotroller;

import java.util.List;

import org.cap.dao.IProductDao;
import org.cap.model.Manufacturer;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {

	
	@Autowired
	private IProductDao productDao;
		
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId") Integer productId){
		List<Product> products=productDao.deleteProduct(productId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not exists! Deletion Error!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products=productDao.getAllProducts();
		
		if(products==null || products.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProducts(
			@PathVariable("productId") Integer productId ){
		Product product=productDao.findProduct(productId);
		
		if(product==null ) {
			return new ResponseEntity("Sorry!Product Id Not Found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	@PostMapping("/persistProduct")
	public  ResponseEntity<List<Product>> createProduct() {
		List<Product> newProducts =  productDao.createProduct();
		if(newProducts==null || newProducts.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(newProducts, HttpStatus.OK);
	}
	
	@PutMapping("/patchProduct/{id}")
    public ResponseEntity<List<Product>> patchProduct(@PathVariable(value = "id") Integer productId) {
		List<Product> updatedProducts=productDao.patchProduct(productId);
		
		if(updatedProducts==null) {
			return new ResponseEntity("Sorry! Product not exists! Error!", 
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(updatedProducts, HttpStatus.OK);
    }
	
	@PutMapping("/updateProducts/{id}")
	public ResponseEntity<List<Product>> updateProduct(@PathVariable(value = "id") Integer productId,
	   @RequestBody Product productDetails) {
		Product product = productDao.findProduct(productId);
		productDetails = getProductDetails();
		product.setProductName(productDetails.getProductName());
		product.setQuantity(productDetails.getQuantity());
		product.setPrice(productDetails.getPrice());
		product.setManufatcturer(productDetails.getManufatcturer());
		List<Product> updatedProducts = productDao.updateProduct(product, productId);
		return new ResponseEntity<List<Product>>(updatedProducts, HttpStatus.OK);
	}
	
	public Product getProductDetails(){
		Manufacturer manufatcturer=new Manufacturer(1, "Tom", "Jerry", "tom@gmail.com");
		return new Product(1234, "Laptop", 34, 45000.0, manufatcturer);
	}
}
