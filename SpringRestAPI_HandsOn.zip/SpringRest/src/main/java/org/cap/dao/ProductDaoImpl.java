package org.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.cap.model.Manufacturer;
import org.cap.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {
	
	
	private static AtomicInteger productId=new AtomicInteger(1234);
	private static AtomicInteger manufacturerId=new AtomicInteger(1);
	private static List<Product> db=getDummyDB(); 
	
	
	private static List<Product> getDummyDB(){
		List<Product> products=new ArrayList<Product>();
			Manufacturer manufatcturer=new Manufacturer(manufacturerId.getAndIncrement(), "Tom", "Jerry", "tom@gmail.com");
			products.add(new Product(productId.getAndIncrement(), "Laptop", 34, 45000.0, manufatcturer));
			products.add(new Product(productId.getAndIncrement(), "Mobile",12, 23000.0, manufatcturer));
			
			Manufacturer manufatcturer1=new Manufacturer(manufacturerId.getAndIncrement(), "Jack", "Thomson", "jack@gmail.com");
			products.add(new Product(productId.getAndIncrement(), "HeadSet", 23, 300.0, manufatcturer1));
			products.add(new Product(productId.getAndIncrement(), "Printer", 11, 67000.0, manufatcturer1));
			
			
		
		return products;
	}
	

	@Override
	public List<Product> getAllProducts() {
		
		return db;
	}


	@Override
	public Product findProduct(Integer productId) {
		for(Product product:db) {
			if(product.getProductId()==productId)
				return product;
		}
		return null;
	}


	@Override
	public List<Product> deleteProduct(Integer productId) {
		boolean flag=false;
		Iterator<Product> iterator = db.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return db;
		else
			return null;
	}
	
	@Override
	public List<Product> createProduct() {
		List<Product> newProducts = new ArrayList<Product>();
		Manufacturer manufatcturer = new Manufacturer(manufacturerId.getAndIncrement(), "Tom", "Jerry",
				"tom@gmail.com");
		newProducts.add(new Product(productId.getAndIncrement(), "Speakers", 34, 45000.0, manufatcturer));
		newProducts.add(new Product(productId.getAndIncrement(), "Mobile", 12, 23000.0, manufatcturer));

		Manufacturer manufatcturer1 = new Manufacturer(manufacturerId.getAndIncrement(), "Jack", "Thomson",
				"jack@gmail.com");
		newProducts.add(new Product(productId.getAndIncrement(), "BlueToothHeadSet", 23, 300.0, manufatcturer1));
		newProducts.add(new Product(productId.getAndIncrement(), "Scanner", 11, 67000.0, manufatcturer1));
		
			db = db.stream()
                .filter(e -> (newProducts.stream()
                        .filter(d -> d.getProductId() !=(e.getProductId())).count() >1))
                        .collect(Collectors.toList());
		
		return db;
	}
	
	@Override
	public List<Product> updateProduct(Product productDetail, Integer productId) {
		boolean flag=false;
		Iterator<Product> iterator = db.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
				db.add(productDetail);
				break;
			}
		}
		if(flag)
			return db;
		else
			return null;
	}
	
	// Say, Here we are performing a partial update - Updating the product name for the passed product id
	@Override
	public List<Product> patchProduct(Integer productId) {
		boolean flag=false;
		Iterator<Product> iterator = db.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				//iterator.remove();
				product.setProductName("Modems");
				db.add(product);
				break;
			}
		}
		if(flag)
			return db;
		else
			return null;
	}
}
